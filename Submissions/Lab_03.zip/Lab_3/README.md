Check ./src/Algorithm_Data.ods for data regarding this assignment

Proper readings were obtained with extremely low (negligible) variance [0.001,0.001,0.001]
Even at [0.1,0.1,0.1], it worked almost fine.
The readings obtained with variance [0.50,0.50,0.50] are not reliable with respect to the problem
